function Submit() {
    let gradeStr = "";
    let grade = document.getElementById("grade").value;

    if (!isNaN(grade)) {
        if (grade <= 5 || grade >= 2){
            if (grade === 5){
                gradeStr = "A";
            }
            if (grade === 4){
                gradeStr = "B";
            }
            if (grade === 3){
                gradeStr = "C";
            }
            if (grade === 2){
                gradeStr = "D";
            }
            if (grade === 1){
                gradeStr = "F";
            }
        }
    }

    let existingDiv = document.querySelector('.valuediv');
    if (existingDiv) {
        existingDiv.remove();
    }

    let gradediv = document.createElement('div');
    gradediv.className = 'valuediv';
    gradediv.innerText = gradeStr

    document.body.appendChild(gradediv);
}
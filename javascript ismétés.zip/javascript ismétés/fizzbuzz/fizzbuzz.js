window.onload = function(){
    let fulloutput = '';
    let strings = [];
    for (let i = 1; i <= 100; i++) {
        if (i % 3 == 0 && i % 5 == 0) {
            strings.push('fizzbuzz');
        }
        else if (i % 5 == 0) {
            strings.push('buzz');
        }
        else if (i % 3 == 0) {
            strings.push('fizz');
        }
        else{
            strings.push(i.toString());
        }

    }
    fulloutput = strings.join(', ');
    let existingDiv = document.querySelector('.valuediv');
    if (existingDiv) {
        existingDiv.remove();
    }

    let numbersdiv = document.createElement('div');
    numbersdiv.className = 'valuediv';
    numbersdiv.innerHTML = fulloutput;

    document.body.appendChild(numbersdiv);
}
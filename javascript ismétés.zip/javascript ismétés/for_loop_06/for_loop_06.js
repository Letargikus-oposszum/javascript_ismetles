function Submit() {
    let number = parseFloat(document.getElementById("year").value);

    var factorial_value = 1;

    if (!isNaN(number)) {
        for (let i = 0; i < number; i++) {
            factorial_value*=i;
        }

        let existingDiv = document.querySelector('.valuediv');
        if (existingDiv) {
            existingDiv.remove();
        }

        let numdiv = document.createElement('div');
        numdiv.className = 'valuediv';
        numdiv.innerText = factorial_value;

        document.body.appendChild(numdiv);
    } else {
        alert("Please enter a valid number for the year.");
    }
}
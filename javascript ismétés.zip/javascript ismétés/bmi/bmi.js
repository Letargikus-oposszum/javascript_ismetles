function Submit() {
    let mass_in_kg = parseFloat(document.getElementById("mass_in_kg").value);
    let height_in_m = parseFloat(document.getElementById("height_in_m").value);

    if (!isNaN(mass_in_kg) && !isNaN(height_in_m)) {
        let bmi = mass_in_kg / (height_in_m * height_in_m);

        let existingDiv = document.querySelector('.valuediv');
        if (existingDiv) {
            existingDiv.remove();
        }

        let bmidiv = document.createElement('div');
        bmidiv.className = 'valuediv';
        bmidiv.innerText = "BMI: " + bmi.toFixed(2);

        document.body.appendChild(bmidiv);
    } else {
        alert("Please enter valid numbers for mass and height.");
    }
}
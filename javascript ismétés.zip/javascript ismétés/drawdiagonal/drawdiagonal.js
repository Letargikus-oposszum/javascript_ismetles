function Submit() {
    let number = parseFloat(document.getElementById("year").value);

    var squarestr = '';

    if (!isNaN(number)) {
        for (let i = 0; i < number; i++) {
            let line = "";
            for (let j = 0; j < number; j++) {
                if (i === 0 || i === number - 1 || j === 0 || j === number - 1 || i === j) {
                    line += "%";
                } else {
                    line += "///";
                }
            }
            squarestr += line + '<br>';
        }

        let existingDiv = document.querySelector('.valuediv');
        if (existingDiv) {
            existingDiv.remove();
        }

        let squarediv = document.createElement('div');
        squarediv.className = 'valuediv';
        squarediv.innerHTML = squarestr;

        document.body.appendChild(squarediv);
    } else {
        alert("Please enter a valid number for the year.");
    }
}
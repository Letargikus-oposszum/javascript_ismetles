function Submit() {
    let year = parseFloat(document.getElementById("year").value);

    if (!isNaN(year)) {
        let answer = "";

        if (year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0)) {
            answer = "Leap year";
        } else {
            answer = "Not a leap year";
        }

        let existingDiv = document.querySelector('.valuediv');
        if (existingDiv) {
            existingDiv.remove();
        }

        let yeardiv = document.createElement('div');
        yeardiv.className = 'valuediv';
        yeardiv.innerText = answer;

        document.body.appendChild(yeardiv);
    } else {
        alert("Please enter a valid number for the year.");
    }
}
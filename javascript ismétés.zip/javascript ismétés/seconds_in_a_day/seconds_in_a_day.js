window.onload = function() {
    let currentHours = 14;
    let currentMinutes = 34;
    let currentSeconds = 42; 
    
    let fullhour = 24;
    let fullminute = 60;
    let fullsecond = 60;

    let remaininghour = fullhour-currentHours;
    let remainingminute = fullminute-currentMinutes;
    let remainingsecond = fullsecond-currentSeconds;

    let fullremainingtime =(remaininghour/60)/60+remainingminute/60+remainingsecond;

    let existingDiv = document.querySelector('.valuediv');
    if (existingDiv) {
        existingDiv.remove();
    }

    let timediv = document.createElement('div');
    timediv.className = 'valuediv';
    timediv.innerText = fullremainingtime;

    document.body.appendChild(timediv);
}
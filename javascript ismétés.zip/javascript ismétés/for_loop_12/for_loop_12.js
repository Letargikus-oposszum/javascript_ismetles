function Submit() {
    let number = document.getElementById("number").value;

    if (!number || isNaN(number)) {
        alert("Please enter a valid number.");
        return;
    }

    let sum = 0;
    let count = number.length;

    for (let i = 0; i < count; i++) {
        sum += parseInt(number[i], 10); 
    }

    let average = sum / count;

    let existingDiv = document.querySelector('.valuediv');
    if (existingDiv) {
        existingDiv.remove();
    }

    let resultDiv = document.createElement('div');
    resultDiv.className = 'valuediv';
    resultDiv.innerText = "The average of digits is " + average;

    document.body.appendChild(resultDiv);
}
window.onload = function() {
    let startnum = 10;
    let endnum = 30;
    let output = '';

    while (startnum <= endnum) {
        let divisors = [];
        let num = startnum;

        let divisor = 1;
        while (divisor <= num) {
            if (num % divisor === 0) {
                divisors.push(divisor);
            }
            divisor++;
        }

        output += num + ": " + divisors.join(', ') + '\n';
        startnum += 1;
    }

    let existingDiv = document.querySelector('.valuediv');
    if (existingDiv) {
        existingDiv.remove();
    }

    let numdiv = document.createElement('div');
    numdiv.className = 'valuediv';
    numdiv.innerText = output;

    document.body.appendChild(numdiv);
};

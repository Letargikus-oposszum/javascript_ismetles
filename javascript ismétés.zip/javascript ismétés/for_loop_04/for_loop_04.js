function Submit() {
    let word = document.getElementById("word").value;

    if (!word) {
        alert("Please enter a word.");
        return;
    }

    let chararray = word.split('');

    let existingDiv = document.querySelector('.valuediv');
    if (existingDiv) {
        existingDiv.remove();
    }

    let worddiv = document.createElement('div');
    worddiv.className = 'valuediv';
    worddiv.innerText = chararray.join(', '); 

    document.body.appendChild(worddiv);
}
window.onload = function(){
    let fulloutput = '';
    let dividableby3 = 0;
    for (let i = 1; i <= 100; i++) {
        if (i % 3 == 0) {
            dividableby3 +=1;
            if (dividableby3 === 2) {
                dividableby3 = 0;
                continue;
            }
        }
        fulloutput += i + ", ";
    }
    let existingDiv = document.querySelector('.valuediv');
    if (existingDiv) {
        existingDiv.remove();
    }

    let numbersdiv = document.createElement('div');
    numbersdiv.className = 'valuediv';
    numbersdiv.innerHTML = fulloutput;

    document.body.appendChild(numbersdiv);
}
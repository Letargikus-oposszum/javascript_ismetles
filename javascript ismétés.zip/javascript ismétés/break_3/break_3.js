function Submit() {
    let word = document.getElementById("word").value;

    if (!word) {
        alert("Please enter a word.");
        return;
    }

    let chararray = word.split('');
    let string = "";

    for (let character of chararray) {
        if (isNaN(character)) {
            string += character;
        } else {
            break;
        }
    }

    let existingDiv = document.querySelector('.valuediv');
    if (existingDiv) {
        existingDiv.remove();
    }

    let worddiv = document.createElement('div');
    worddiv.className = 'valuediv';
    worddiv.innerText = string

    document.body.appendChild(worddiv);
}